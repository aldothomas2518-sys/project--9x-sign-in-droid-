PROJECT OBSIDIAN — ANDROID APK BUILDER

This is an Android Studio project wrapper around the current Project Obsidian v2 Character Forge web app. It is intended to produce an installable debug APK using GitHub Actions, so an Android SDK/PC is not needed locally.

WHAT IS INCLUDED
- Android app shell (Kotlin + WebView)
- Project Obsidian v2 HTML bundled inside the app
- Local WebView storage enabled
- GitHub Actions workflow to build and publish the APK as an artifact

HOW TO BUILD USING ONLY YOUR PHONE
1. Download and extract this ZIP.
2. In your phone browser, open github.com and sign in/create an account.
3. Create a new repository named project-obsidian-android.
4. Upload the extracted project files and folders to the repository, preserving the folder structure (including .github/workflows/build-apk.yml).
5. Open the repository's Actions tab.
6. Select "Build Project Obsidian APK".
7. Tap "Run workflow".
8. When the run completes, open it and download the artifact named project-obsidian-debug-apk.
9. Extract the artifact ZIP and tap app-debug.apk to install. Android may ask permission to install from that source.

IMPORTANT
- This is a debug APK build route, not a Play Store release.
- The APK wraps the current browser-based app; it does not magically add cloud sync, Google sign-in, push notifications, cinematic effects, or a native character-rendering engine.
- App data is stored locally inside the Android WebView. Uninstalling the app may erase it; use the in-app JSON export to back up.
- The project has not been compiled or tested in this environment because Android SDK/Gradle are not installed here.

Build workflow note: the GitHub Actions workflow installs Gradle 8.9 and runs assembleDebug. The workflow produces a debug APK artifact when it completes successfully.
